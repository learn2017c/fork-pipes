/* Requiment */
- install cmake 3.1 or onwards

/* building out of source */
  $ mkdir build   // creates a temporary build directory
  $ cd build
  $ cmake ..      // generates the Makefile
  $ make          // generates the executables and they are found in bin/ folder 

 /* Running the executables */
  $ cd bin
  $ ./client      // to run the client feks. 
  $ ./server      // to run the server feks. 
