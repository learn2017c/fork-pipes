#include "client.h"
#include "queue.h"
#include <messages.h>
#include <stdio.h>
#include <stdlib.h>

static void help()
{
	printf("./client <ip> <port>\n");
	printf("	<ip>   : ip to use\n");
	printf("	<port> : port to use\n");
}
void message(){
	printf("Getting number of job from the server has been selected.\n");

}

int main(int argc, char* argv [])
{
	/*
	 * Check arguments used. has to have 2 args
	 */
	if(argc < 3)
	{
		help();
		return -1;
	}

	printf("Client Started\n");

	/*
	 * Create Queue
	 */
	int queueSize = 16;
	struct Client client;
	client.m_queue[0] = queueCreate(queueSize);
	client.m_queue[1] = queueCreate(queueSize);

	/*
	 * Initialize TCP
	 */
	client.m_tcp.m_ip = argv[1];
	client.m_tcp.m_port = atoi(argv[2]);

	/*
	 * Get input from User
	 */

	 char option;
	 char numJobs;
   printf("1 - Get one Job from server.\n");
   printf("2 - Get X number of jobs from the server\n");
   printf("3 - Get all jobs from the server\n");
   printf("4 - Quit Program\n\n");

   scanf("%s", &option);

   switch(option)
	 {
		 case'1':
		 	printf("Getting one job from the server has been selected.\n");
      break;
     case'2':
			 printf("Enter number of jobs to get from the server:\n");
			 scanf("%s", &numJobs);
			 void message();
       break;
     case'3':
			 printf("Getting all jobs from the server has been selected.\n");
       break;
     case'4':
       printf("Quiting program.\n");
       break;
 		 default:
			 printf("Invald choice  %d\n", option);
			 return -1;
		 }

		   int p,fA,fB;
		   int childA,childB;
		   int pipeClientToChildA[2];
		   int pipeClientToChildB[2];
		   char message[20];

		   p= pipe(pipeClientToChildA);
		   if(p < 0){
		     printf("Error Creating piple for Child A.");
		     _exit(1);
		   }

		   p= pipe(pipeClientToChildB);
		   if(p < 0){
		     printf("Error Creating piple for Child B.");
		     _exit(1);
		   }


		   fA = fork();
		   if(fA > 0){
		     write(pipeClientToChildA[1], "ClientToChildA:Normal Output.", 15);
		   }
		   else if(fA == 0){
		     read(pipeClientToChildA[0],message,15);
		     printf("%s %d\n", message);

		     fB = fork();
		     if(fB > 0){
		       write(pipeClientToChildB[1], "ClientToChildB:Normal Output.", 15);
		     }
		     else if(fB== 0){
		       read(pipeClientToChildB[0],message,15);
		       printf("%s %d\n", message);
		     }
		     else{
		       printf("Error creating child processes.");
		     }


		   }
		   else{
		     printf("Error creating child processes.");
		   }



		   while(1);

		   return 0;

		 }

//	/*
//	 * FIFO queue
//	 */
//	int size = 10;
//	QueuePtr queue = queueCreate(size);
//	if(queue)
//	{
//		enqueue(queue, 10);
//		enqueue(queue, 3);
//		printf("queue->m_size = %d\n", queue->m_stack1->m_size);
//		while(!queueIsEmpty(queue))
//		{
//			ServerMessagePtr data = dequeue(queue);
//
//			if(ServerMessagePtr)
//			{
//				printf("queue->m_stack = %s\n", ServerMessagePtr->JobInfo); //TODO
//        printf("queue->jobTextLength = %s\n", ServerMessagePtr->jobTextLength);
//			}
//		}
//
//		queueDestroy(queue);
//	}

	queueDestroy(client.m_queue[0]);
	queueDestroy(client.m_queue[1]);

	return 0;
}
