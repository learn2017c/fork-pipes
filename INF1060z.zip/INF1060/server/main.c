#include "server.h"
#include <stdio.h>

int main(int argc, char* argv [])
{
	printf("Server Started\n");

	return 0;
}
